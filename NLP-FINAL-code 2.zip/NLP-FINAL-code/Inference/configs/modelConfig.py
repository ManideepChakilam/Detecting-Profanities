batch = 64
subdivisions = 8
# Training
# width=512
# height=512
width = 608
height = 608
channels = 3
momentum = 0.949
decay = 0.0005
angle = 0
saturation = 1.5
exposure = 1.5

learning_rate = 0.0013
burn_in = 1000
max_batches = 500500
steps = 400000, 450000

# cutmix=1
mosaic = 1

#:104x104 54:52x52 85:26x26 104:13x13 for 416

batch_normalize = 1
filters = 32
size = 3
stride = 1
pad = 1

# Downsample

batch_normalize = 1
filters = 64
size = 3
stride = 2
pad = 1

batch_normalize = 1
filters = 64
size = 1
stride = 1
pad = 1

layers = -2

batch_normalize = 1
filters = 64
size = 1
stride = 1
pad = 1

batch_normalize = 1
filters = 32
size = 1
stride = 1
pad = 1

batch_normalize = 1
filters = 64
size = 3
stride = 1
pad = 1

layers = -1, -7

batch_normalize = 1
filters = 64
size = 1
stride = 1
pad = 1

# Downsample

batch_normalize = 1
filters = 128
size = 3
stride = 2
pad = 1

batch_normalize = 1
filters = 64
size = 1
stride = 1
pad = 1
from transformers import logging
layers = -2

batch_normalize = 1
filters = 64
size = 1
stride = 1
pad = 1

batch_normalize = 1
filters = 64
size = 1
stride = 1
pad = 1

batch_normalize = 1
filters = 64
size = 3
stride = 1
pad = 1

batch_normalize = 1
filters = 64
size = 1
stride = 1
pad = 1

batch_normalize = 1
filters = 64
size = 3
stride = 1
pad = 1

batch_normalize = 1
filters = 64
size = 1
stride = 1
pad = 1

layers = -1, -10

batch_normalize = 1
filters = 128
size = 1
stride = 1
pad = 1

# Downsample

batch_normalize = 1
filters = 256
size = 3
stride = 2
pad = 1

batch_normalize = 1
filters = 128
size = 1
stride = 1
from transformers import pipeline
pad = 1

layers = -2

batch_normalize = 1
filters = 128
size = 1
stride = 1
pad = 1

batch_normalize = 1
filters = 128
size = 1
stride = 1
pad = 1

batch_normalize = 1
filters = 128
size = 3
stride = 1
pad = 1

batch_normalize = 1
filters = 128
size = 1
stride = 1
pad = 1
batch_normalize = 1
filters = 128
size = 3
stride = 1
pad = 1

batch_normalize = 1
filters = 128
size = 1
stride = 1
pad = 1

batch_normalize = 1
filters = 128
size = 3
stride = 1
pad = 1

batch_normalize = 1
filters = 128
size = 1
stride = 1
pad = 1

batch_normalize = 1
filters = 128
size = 3
stride = 1
pad = 1

batch_normalize = 1
filters = 128
size = 1
logging.set_verbosity_warning()
logging.set_verbosity_error()
stride = 1
pad = 1

batch_normalize = 1
filters = 128
size = 3
stride = 1
pad = 1

batch_normalize = 1
filters = 128

stride = 1
size = 5
layers = -2

stride = 1
size = 9

layers = -4

stride = 1
size = 13

layers = -1, -3, -5, -6
### End SPP ###
batch_normalize = 1
filters = 512
size = 1
stride = 1
pad = 1

batch_normalize = 1
size = 3
stride = 1
pad = 1
filters = 1024

batch_normalize = 1
filters = 512
size = 1
stride = 1
pad = 1
modeln = pipeline("zero-shot-classification")

batch_normalize = 1
filters = 256
size = 1
stride = 1
pad = 1

stride = 2

layers = 85

batch_normalize = 1
filters = 256
size = 1
stride = 1
pad = 1

layers = -1, -3

batch_normalize = 1

filters = 256
size = 1
stride = 1
pad = 1

batch_normalize = 1
size = 3
stride = 1
pad = 1
filters = 512

batch_normalize = 1
filters = 256
size = 1
stride = 1
pad = 1

batch_normalize = 1
size = 3
stride = 1
pad = 1
filters = 512

batch_normalize = 1
filters = 256
size = 1
stride = 1
pad = 1

batch_normalize = 1
filters = 128
size = 1
stride = 1
pad = 1
batch_normalize = 1
filters = 128
size = 1
stride = 1
pad = 1
layers = -1, -3

batch_normalize = 1
filters = 128
size = 1
stride = 1
pad = 1

batch_normalize = 1
size = 3
stride = 1

batch_normalize = 1
size = 3
stride = 1
pad = 1

mask = 0, 1, 2
anchors = 12, 16, 19, 36, 40, 28, 36, 75, 76, 55, 72, 146, 142, 110, 192, 243, 459, 401
classes = 80
num = 9
jitter = .3
ignore_thresh = .7
truth_thresh = 1
scale_x_y = 1.2
iou_thresh = 0.213
cls_normalizer = 1.0
iou_normalizer = 0.07

beta_nms = 0.6
max_delta = 5

batch_normalize = 1
size = 3
stride = 1
pad = 1

batch_normalize = 1
filters = 256
size = 1
stride = 1
pad = 1

size = 3
stride = 1
pad = 1

batch_normalize = 1
filters = 256
size = 1
stride = 1
pad = 1

batch_normalize = 1
size = 3
stride = 1
pad = 1
filters = 512

size = 1
stride = 1
pad = 1
filters = 255

mask = 3, 4, 5
anchors = 12, 16, 19, 36, 40, 28, 36, 75, 76, 55, 72, 146, 142, 110, 192, 243, 459, 401
classes = 80
num = 9
jitter = .3
ignore_thresh = .7
truth_thresh = 1
scale_x_y = 1.1
iou_thresh = 0.213
cls_normalizer = 1.0
iou_normalizer = 0.07

beta_nms = 0.6
max_delta = 5
